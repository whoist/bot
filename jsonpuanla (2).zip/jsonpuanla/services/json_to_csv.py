import json
import math
from services.openai_client import openai_client

async def json_to_csv_with_gpt(json_data, existing_csv=None):
    # JSON verisini 20 parçaya böl
    json_chunks = split_json(json_data, 20)
    csv_results = []

    # Eğer mevcut CSV varsa, başlığı ayır ve sonuçlara ekle
    if existing_csv:
        csv_lines = existing_csv.strip().split('\n')
        header = csv_lines[0]
        csv_results.append(header)
        existing_data = '\n'.join(csv_lines[1:])
    else:
        header = None
        existing_data = None

    for i, chunk in enumerate(json_chunks):
        prompt = f"Aşağıdaki JSON verisini CSV formatına dönüştür:\n\n{json.dumps(chunk, indent=2)}\n\nCSV çıktısı:"
        
        if i == 0 and header:
            prompt += f"\n\nMevcut CSV başlığı: {header}\nLütfen bu başlığı kullan ve yeni satırları ekle."
        elif i > 0:
            prompt += "\nLütfen sadece veri satırlarını döndür, başlığı dahil etme."

        chat_completion = openai_client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[
                {"role": "system", "content": "Sen bir JSON'dan CSV'ye dönüştürme uzmanısın."},
                {"role": "system", "content": open('prompt.txt').read()},
                {"role": "user", "content": prompt}
            ]
        )
        
        result = chat_completion.choices[0].message.content.strip()
        if i > 0:
            # Başlığı kaldır (eğer varsa)
            result_lines = result.split('\n')
            if ',' in result_lines[0]:  # Basit bir başlık kontrolü
                result = '\n'.join(result_lines[1:])
        csv_results.append(result)
    
    # Tüm CSV sonuçlarını birleştir
    final_csv = "\n".join(csv_results)
    
    # Eğer mevcut veri varsa, yeni veriyi ekle
    if existing_data:
        final_csv = f"{final_csv}\n{existing_data}"
    
    return final_csv


def split_json(json_data, num_chunks):
    if isinstance(json_data, list):
        chunk_size = math.ceil(len(json_data) / num_chunks)
        return [json_data[i:i + chunk_size] for i in range(0, len(json_data), chunk_size)]
    elif isinstance(json_data, dict):
        items = list(json_data.items())
        chunk_size = math.ceil(len(items) / num_chunks)
        chunks = [dict(items[i:i + chunk_size]) for i in range(0, len(items), chunk_size)]
        return chunks
    else:
        raise ValueError("JSON verisi bir liste veya sözlük olmalıdır.")