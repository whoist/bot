import json
from openai import OpenAI

with open('config.json') as config_file:
    config = json.load(config_file)

openai_client = OpenAI(
    api_key=config["OPENAI_API_KEY"]
)