import logging
from telethon import TelegramClient, events
from bot.handlers import start_handler, document_handler

class TelegramBot:
    def __init__(self, api_id, api_hash, bot_token):
        self.client = TelegramClient('bot', api_id, api_hash).start(bot_token=bot_token)
        self.setup_handlers()

    def setup_handlers(self):
        self.client.on(events.NewMessage(pattern='/start'))(start_handler)
        self.client.on(events.NewMessage)(document_handler)

    def run(self):
        self.client.run_until_disconnected()