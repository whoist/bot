import logging
import json
import io
from services.json_to_csv import json_to_csv_with_gpt
from openpyxl import Workbook

logger = logging.getLogger(__name__)

async def start_handler(event):
    logger.info(f"\033[92mKullanıcı başlattı: {event.sender_id}\033[0m")  # Yeşil renk
    await event.respond('Merhaba! Lütfen bir JSON dosyası gönderin.')

def create_files_from_csv(csv_content):
    csv_file = io.BytesIO(csv_content.encode('utf-8'))
    csv_file.seek(0)
    
    wb = Workbook()
    ws = wb.active
    for row in csv_content.split('\n'):
        ws.append(row.split(','))
    
    excel_file = io.BytesIO()
    wb.save(excel_file)
    excel_file.seek(0)
    
    return csv_file, excel_file

async def document_handler(event):
    if event.file and event.file.name.lower().endswith('.json'):
        user_id = event.sender_id
        logger.info(f"\033[92mKullanıcı {user_id} bir dosya gönderdi\033[0m")  # Yeşil renk
        
        hazirlaniyor_mesaj = await event.respond("📄 Dosyalarınız hazırlanıyor...")

        json_content = await event.download_media(bytes)
        
        try:
            json_data = json.loads(json_content)
            yeni_json = []
            for mesaj in json_data["messages"]:
                yeni_mesaj = {
                    "id": mesaj.get("id"),
                    "from": mesaj.get("from"),
                    "from_id": mesaj.get("from_id"),
                    "text": mesaj.get("text")
                }
                yeni_json.append(yeni_mesaj)
            
            csv_content = await json_to_csv_with_gpt(yeni_json)
            
            csv_file, excel_file = create_files_from_csv(csv_content)
            
            await hazirlaniyor_mesaj.delete()
            
            await event.client.send_file(event.chat_id, csv_file, caption="Dönüştürülmüş CSV dosyası", file_name="converted.csv", reply_to=event.id)
            await event.client.send_file(event.chat_id, excel_file, caption="Dönüştürülmüş Excel dosyası", file_name="converted.xlsx", reply_to=event.id)
            
            logger.info(f"\033[92mKullanıcı {user_id} için CSV ve Excel dönüşümü tamamlandı\033[0m")  # Yeşil renk
        except json.JSONDecodeError:
            logger.error(f"\033[91mKullanıcı {user_id} geçersiz JSON dosyası gönderdi\033[0m")  # Kırmızı renk
            await event.respond("Geçersiz JSON dosyası. Lütfen doğru formatta bir JSON dosyası gönderin.")
    else:
        logger.warning(f"\033[93mKullanıcı {event.sender_id} desteklenmeyen bir dosya türü gönderdi\033[0m")  # Sarı renk
        await event.respond("Lütfen bir JSON dosyası gönderin.")