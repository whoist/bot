# Telegram JSON to CSV Dönüştürücü Bot

Bu proje, Telegram gruplarından alınan JSON formatındaki sohbet geçmişini CSV formatına dönüştüren bir bot içerir. Bot, OpenAI GPT-3.5 modelini kullanarak içeriği analiz eder ve puanlar.

## Gereksinimler

- Docker
- Docker Compose

## Kurulum

1. Projeyi klonlayın:
   ```
   git clone https://github.com/kullanici_adi/proje_adi.git
   cd proje_adi
   ```

2. `config.json` dosyasını oluşturun ve gerekli bilgileri ekleyin:
   ```json
   {
       "TELEGRAM_API_ID": "your_api_id",
       "TELEGRAM_API_HASH": "your_api_hash",
       "TELEGRAM_BOT_TOKEN": "your_bot_token",
       "OPENAI_API_KEY": "your_openai_api_key"
   }
   ```

3. Docker imajını oluşturun ve container'ı başlatın:
   ```
   docker-compose build
   docker-compose up -d
   ```

## Kullanım

1. Telegram'da botu başlatın ve `/start` komutunu gönderin.
2. Bot size bir JSON dosyası göndermenizi isteyecektir.
3. JSON dosyasını gönderin.
4. Bot, dosyayı işleyecek ve size dönüştürülmüş CSV dosyasını gönderecektir.

## Dosya Yapısı

- `main.py`: Ana uygulama dosyası
- `bot/`: Telegram bot işlevselliği
- `services/`: JSON to CSV dönüşümü ve OpenAI entegrasyonu
- `Dockerfile`: Docker imajı yapılandırması
- `docker-compose.yml`: Docker Compose yapılandırması
- `requirements.txt`: Python bağımlılıkları
- `config.json`: Yapılandırma dosyası (gizli tutulmalıdır)
- `prompt.txt`: OpenAI için kullanılan prompt

## Güvenlik Notları

- `config.json` dosyasını asla GitHub'a push etmeyin. Bu dosya `.gitignore` dosyasına eklenmelidir.
- Hassas bilgileri (API anahtarları, tokenlar vb.) güvenli bir şekilde saklayın ve yönetin.

## Sorun Giderme

Eğer botla ilgili herhangi bir sorun yaşarsanız, lütfen şu adımları izleyin:

1. Docker container'ının çalıştığından emin olun: `docker-compose ps`
2. Logları kontrol edin: `docker-compose logs bot`
3. Gerekirse container'ı yeniden başlatın: `docker-compose restart bot`

## Katkıda Bulunma

Projeye katkıda bulunmak isterseniz, lütfen bir Pull Request açın. Büyük değişiklikler için önce bir konu açarak tartışmaya açın.

## Lisans

Bu proje [MIT Lisansı](LICENSE) altında lisanslanmıştır.